<?php
session_start();
include 'functions.php'; // Include your database connection functions

$pdo = pdo_connect_mysql();

header('Content-Type: application/json');

// Get the JSON data from the request
$data = json_decode(file_get_contents('php://input'), true);

// Validate the input data
if (!isset($data['items']) || !isset($data['totalAmount']) || !isset($data['paymentMethod'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid input data']);
    exit;
}

// Prepare to insert the order into the Orders table
try {
    // Start a transaction
    $pdo->beginTransaction();

    // Insert the order into the Orders table
    $stmt = $pdo->prepare("INSERT INTO Orders (customerID, totalAmount, orderStatus) VALUES (?, ?, ?)");
    $customerID = $_SESSION['customerID']; // Assuming you have the customer ID stored in the session
    $totalAmount = $data['totalAmount'];
    $orderStatus = 'Pending'; // Default status
    $stmt->execute([$customerID, $totalAmount, $orderStatus]);

    // Get the last inserted order ID
    $orderID = $pdo->lastInsertId();

    // Insert each item into the OrderItems table
    foreach ($data['items'] as $item) {
        $stmt = $pdo->prepare("INSERT INTO OrderItems (orderID, productID, quantity, price) VALUES (?, ?, ?, ?)");
        $stmt->execute([$orderID, $item['id'], $item['quantity'], $item['price']]);
    }

    // Insert payment details
    $stmt = $pdo->prepare("INSERT INTO PaymentDetail (orderID, customerID, paymentMethod, totalPaid) VALUES (?, ?, ?, ?)");
    $stmt->execute([$orderID, $customerID, $data['paymentMethod'], $totalAmount]);

    // Commit the transaction
    $pdo->commit();

    echo json_encode(['success' => true, 'message' => 'Order placed successfully!']);
} catch (Exception $e) {
    // Rollback the transaction if something failed
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Error placing order: ' . $e->getMessage()]);
}
?>