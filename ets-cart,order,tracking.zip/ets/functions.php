<?php
function pdo_connect_mysql() {
    $DATABASE_HOST = 'localhost'; // Your database host
    $DATABASE_USER = 'root'; // Your database username
    $DATABASE_PASS = ''; // Your database password
    $DATABASE_NAME = 'ets_db'; // Your database name

    try {
        return new PDO('mysql:host=' . $DATABASE_HOST . ';dbname=' . $DATABASE_NAME, $DATABASE_USER, $DATABASE_PASS);
    } catch (PDOException $exception) {
        exit('Failed to connect to database: ' . $exception->getMessage());
    }
}
?>