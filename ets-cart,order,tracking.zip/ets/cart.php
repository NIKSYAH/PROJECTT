<?php
session_start();
include 'functions.php'; // Include your database connection functions

$pdo = pdo_connect_mysql();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle adding/updating/removing items in the cart
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        $productId = $_POST['product_id'];
        $quantity = $_POST['quantity'] ?? 1;

        // Initialize cart if not set
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        if ($action === 'add') {
            // Add or update item in cart
            if (isset($_SESSION['cart'][$productId])) {
                $_SESSION['cart'][$productId] += $quantity; // Update quantity
            } else {
                $_SESSION['cart'][$productId] = $quantity; // Add new item
            }
        } elseif ($action === 'update') {
            // Update item quantity
            if (isset($_SESSION['cart'][$productId])) {
                $_SESSION['cart'][$productId] = $quantity;
            }
        } elseif ($action === 'remove') {
            // Remove item from cart
            unset($_SESSION['cart'][$productId]);
        }
    }
}

// Fetch cart items for display
$cartItems = [];
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $productId => $quantity) {
        $stmt = $pdo->prepare('SELECT * FROM Product WHERE productID = ?');
        $stmt->execute([$productId]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($product) {
            $product['quantity'] = $quantity; // Add quantity to product data
            $cartItems[] = $product;
        }
    }
}

// Return cart items as JSON
header('Content-Type: application/json');
echo json_encode($cartItems);
?>