<?php
session_start();
include 'functions.php'; // Include your database connection functions

$pdo = pdo_connect_mysql();

header('Content-Type: application/json');

// Get the order ID from the query string
$orderId = isset($_GET['orderId']) ? intval($_GET['orderId']) : 0;

// Validate the order ID
if ($orderId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid Order ID']);
    exit;
}

// Prepare to fetch the order details
try {
    // Fetch order details
    $stmt = $pdo->prepare("SELECT * FROM Orders WHERE orderID = ?");
    $stmt->execute([$orderId]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        echo json_encode(['success' => false, 'message' => 'Order not found']);
        exit;
    }

    // Fetch order items
    $stmt = $pdo->prepare("SELECT oi.*, p.name FROM OrderItems oi JOIN Product p ON oi.productID = p.productID WHERE oi.orderID = ?");
    $stmt->execute([$orderId]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Prepare the response data
    $response = [
        'success' => true,
        'order' => [
            'orderID' => $order['orderID'],
            'customerName' => $order['customerName'], // Assuming you have this field in Orders
            'totalAmount' => $order['totalAmount'],
            'status' => $order['orderStatus'],
            'items' => array_map(function($item) {
                return [
                    'name' => $item['name'],
                    'price' => $item['price'],
                    'quantity' => $item['quantity']
                ];
            }, $items)
        ]
    ];

    echo json_encode($response);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error fetching order details: ' . $e->getMessage()]);
}
?>